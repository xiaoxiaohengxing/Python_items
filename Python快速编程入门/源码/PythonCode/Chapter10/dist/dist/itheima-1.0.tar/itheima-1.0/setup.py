from distutils.core import setup
setup(name="itheima", version="1.0", description="itheima  belongs to itcast",
author="itcast", py_modules=['suba.aa', 'suba.bb', 'subb.cc', 'subb.dd'])
